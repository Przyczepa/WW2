<?php
        if(isset($_COOKIE['od'])){
            $od=$_COOKIE['od'];
            $od+=1;
        }
        else{
            $od=1;
        }
        setcookie('od',$od,time()+3600);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Odloty samolotów</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>
    <header id="head1">
        <h2>Odloty z lotniska</h2>
    </header>
    <header id="head2">
        <img src="zad6.png" alt="logotyp">
    </header>
    <main>
        <h4>tabela odlotów</h4>
        <table>
            <tr>
                <th>lp.</th><th>numer rejsu</th><th>czas</th><th>kierunek</th><th>status</th>
            </tr>
                <?php
                    $c=mysqli_connect("localhost","root","","egzamin");
                    $q="SELECT id, nr_rejsu, czas, kierunek, status_lotu FROM odloty GROUP BY czas DESC;";
                    $r=mysqli_query($c,$q);
                    while($row=mysqli_fetch_array($r)){
                        echo"<tr><td>".$row[0]."</td> <td>".$row[1]."</td> <td>".$row[2]."</td> <td>".$row[3]."</td><td>".$row[4]."</td></tr>";
                    }
                    mysqli_close($c);
                ?>
        </table>
    </main>
    <footer id="foot1">
        <a href="kw1.jpg" target="_blank">Pobierz obraz</a>
    </footer>
    
    <footer id="foot2">
        <?php
        if($od==1){
            echo"<P><I>Dzień dobry! Sprawdz regulamin naszej strony</I></P>";
        }
        else{
            echo"<p><b>Miło nam, że nas znowu odwiedziłeś</b></p>";
        }
        ?>
    </footer>
    
    <footer id="foot3">
        Autor Krystian Szewczyk
    </footer>
</body>
</html>